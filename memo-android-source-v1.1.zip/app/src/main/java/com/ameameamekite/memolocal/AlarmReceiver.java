package com.ameameamekite.memolocal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        String kind = intent.getStringExtra("kind");
        String note = intent.getStringExtra("note");
        NotificationHelper.show(context, id, title, kind, note);
        ReminderScheduler.scheduleFromPrefs(context);
    }
}
