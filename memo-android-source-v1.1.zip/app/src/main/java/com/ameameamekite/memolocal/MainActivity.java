package com.ameameamekite.memolocal;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int REQUEST_NOTIFICATIONS = 401;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotificationHelper.createChannel(this);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new MemoBridge(this), "MemoAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript("if(window.memoSyncToNative){window.memoSyncToNative();}", null);
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/web/index.html");

        new Handler(Looper.getMainLooper()).postDelayed(() -> ensureNotificationAccess(false), 700);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_NOTIFICATIONS) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> ensureNotificationAccess(false), 250);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ReminderScheduler.scheduleFromPrefs(this);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    void ensureNotificationAccess(boolean forceExactSettings) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            return;
        }

        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (manager != null && !manager.canScheduleExactAlarms()) {
                SharedPreferences prefs = getSharedPreferences("memo_native", MODE_PRIVATE);
                boolean asked = prefs.getBoolean("asked_exact_alarm", false);
                if (forceExactSettings || !asked) {
                    prefs.edit().putBoolean("asked_exact_alarm", true).apply();
                    new AlertDialog.Builder(this)
                        .setTitle("允许准点提醒")
                        .setMessage("为了让备忘在 App 没打开、手机休眠时也尽量按你设定的时间弹出，需要开启系统的“闹钟和提醒”权限。不开也能用，但提醒可能被系统延后。")
                        .setNegativeButton("暂时不要", null)
                        .setPositiveButton("去开启", (dialog, which) -> {
                            try {
                                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                    Uri.parse("package:" + getPackageName()));
                                startActivity(intent);
                            } catch (Exception e) {
                                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + getPackageName()));
                                startActivity(intent);
                            }
                        })
                        .show();
                }
            }
        }
    }

    public static class MemoBridge {
        private final MainActivity activity;

        MemoBridge(MainActivity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public void syncReminders(String json) {
            activity.getSharedPreferences("memo_native", MODE_PRIVATE)
                .edit().putString("reminders_json", json).apply();
            ReminderScheduler.scheduleAll(activity.getApplicationContext(), json);
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            activity.runOnUiThread(() -> activity.ensureNotificationAccess(true));
        }
    }
}
