package com.ameameamekite.memolocal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public final class ReminderScheduler {
    private static final String PREFS = "memo_native";
    private static final String JSON_KEY = "reminders_json";
    private static final String IDS_KEY = "scheduled_ids";

    private ReminderScheduler() {}

    public static void scheduleFromPrefs(Context context) {
        String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(JSON_KEY, "[]");
        scheduleAll(context, json);
    }

    public static synchronized void scheduleAll(Context context, String json) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        cancelPreviouslyScheduled(context, alarmManager, prefs);

        JSONArray scheduledIds = new JSONArray();
        try {
            JSONArray array = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;

                String id = item.optString("id", "");
                String title = item.optString("title", "备忘提醒");
                String kind = item.optString("kind", "task");
                String note = item.optString("note", "");
                boolean done = item.optBoolean("done", false);
                boolean repeatYearly = item.optBoolean("repeatYearly", false);
                if (id.isEmpty() || ("task".equals(kind) && done)) continue;

                long triggerAt = computeTriggerMillis(item);
                if (triggerAt <= System.currentTimeMillis()) continue;

                Intent intent = new Intent(context, AlarmReceiver.class);
                intent.setAction("com.ameameamekite.memolocal.REMINDER." + id);
                intent.putExtra("id", id);
                intent.putExtra("title", title);
                intent.putExtra("kind", kind);
                intent.putExtra("note", note);
                intent.putExtra("repeatYearly", repeatYearly);

                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode(id),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                if (Build.VERSION.SDK_INT >= 31 && alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
                }
                scheduledIds.put(id);
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString(IDS_KEY, scheduledIds.toString()).apply();
    }

    private static void cancelPreviouslyScheduled(Context context, AlarmManager manager, SharedPreferences prefs) {
        try {
            JSONArray ids = new JSONArray(prefs.getString(IDS_KEY, "[]"));
            for (int i = 0; i < ids.length(); i++) {
                String id = ids.optString(i, "");
                if (id.isEmpty()) continue;
                Intent intent = new Intent(context, AlarmReceiver.class);
                intent.setAction("com.ameameamekite.memolocal.REMINDER." + id);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    requestCode(id),
                    intent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                );
                if (pendingIntent != null) {
                    manager.cancel(pendingIntent);
                    pendingIntent.cancel();
                }
            }
        } catch (Exception ignored) {
        }
    }

    private static long computeTriggerMillis(JSONObject item) {
        try {
            String dateString = item.optString("date", "");
            if (dateString.isEmpty()) return -1L;
            LocalDate original = LocalDate.parse(dateString);
            String timeString = item.optString("time", "");
            LocalTime time = timeString.isEmpty() ? LocalTime.of(9, 0) : LocalTime.parse(timeString);
            boolean yearly = item.optBoolean("repeatYearly", false);

            ZoneId zone = ZoneId.systemDefault();
            ZonedDateTime now = ZonedDateTime.now(zone);
            LocalDate targetDate = original;
            if (yearly) {
                int year = now.getYear();
                int day = Math.min(original.getDayOfMonth(), original.getMonth().length(java.time.Year.isLeap(year)));
                targetDate = LocalDate.of(year, original.getMonth(), day);
                ZonedDateTime candidate = ZonedDateTime.of(targetDate, time, zone);
                if (!candidate.isAfter(now)) {
                    year++;
                    day = Math.min(original.getDayOfMonth(), original.getMonth().length(java.time.Year.isLeap(year)));
                    targetDate = LocalDate.of(year, original.getMonth(), day);
                }
            }
            return ZonedDateTime.of(targetDate, time, zone).toInstant().toEpochMilli();
        } catch (Exception e) {
            return -1L;
        }
    }

    private static int requestCode(String id) {
        return id.hashCode() & 0x7fffffff;
    }
}
