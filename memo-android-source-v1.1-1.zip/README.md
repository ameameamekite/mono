# 备忘 · Android 原生提醒版 v1.1

独立于碎片库。

## 已修正
v1 原源码里网页保存的提醒没有同步到 Android 原生层，所以即使 APK 编译成功，也可能只在界面里看得到，AlarmManager 实际没有收到日程。

v1.1 已加入：
- 新增 / 编辑提醒后立即同步 Android AlarmManager
- 删除提醒后立即取消并重排
- 勾选完成后立即重排
- 导入备份后立即同步
- App 打开完成后自动同步一次

## 原生提醒
- App 关闭、手机休眠时可由 Android AlarmManager 触发
- 填时间：按填写时间提醒
- 不填时间：当天 09:00
- 生日 / 纪念日：每年自动排下一次
- 重启、改时间、改时区后重新排程
- Android 13+ 申请通知权限
- Android 12+ 可申请“闹钟和提醒”精确闹钟权限

## 初始日程
2026-10-11 · 去日本看演唱会

包名：com.ameameamekite.memolocal


## v1.1.1 构建修复
- 修复 app/build.gradle 中 GitHub Actions 环境下 versionCode 取值为 null 导致的构建失败。
- versionCode 固定为 1。
- versionName 固定为 1.1.1。
